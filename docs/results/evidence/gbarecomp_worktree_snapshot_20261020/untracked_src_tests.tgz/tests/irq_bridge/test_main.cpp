// irq_bridge_tests — IRQ-continuation boundary of the interpreter miss bridge.
//
// Regression for: runtime_bridge_interpret() in IRQ-continuation mode kept
// interpreting the INTERRUPTED mainline past the handler's own exception return
// whenever the return PC was not a static (native) entry, so the interrupted
// instruction retired once in the bridge and again when control returned to its
// real owner (SMA2: Thumb beq 0x08000534, +8 cycles).
//
// Every scenario is run twice from an identical machine: once through the
// production miss bridge (runtime_dispatch / runtime_irq), once through the
// forced-interpreter reference (one instruction per step, never over-runs).
// The per-instruction fingerprint streams (pc, cpsr, r0-r15, cycles), final
// state, cycle clock and IRQ counters must be identical. Direct-IRQ scenarios
// additionally assert the exact boundary: after runtime_irq() returns, PC is the
// return address and no instruction of the interrupted context has retired.
//
// The cart dispatch table here has two "static" entries (0x08000008 and the stop
// address 0x08000010); a static entry executes via one forced-interpreter step so
// its cost is the interpreter's. Everything else misses and is bridged.

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

#include "gba_bios.h"
#include "gba_bus.h"
#include "gba_ppu.h"
#include "runtime_arm.h"
#include "runtime_bus_bridge.h"
#include "runtime_context.h"

struct DispatchEntry { uint32_t addr; uint8_t thumb; uint8_t resume; void (*fn)(void); };
static void static_entry_step(void) { runtime_force_interp_step(); }
extern "C" const DispatchEntry kDispatchTable[] = {
    {0x08000008u, 0u, 0u, static_entry_step},
    {0x08000010u, 0u, 0u, static_entry_step},
};
extern "C" const unsigned kDispatchTableLen = 2u;

extern "C" unsigned long long g_runtime_irq_entries;
extern "C" uint32_t g_irq_nest_depth;
extern "C" uint32_t g_irq_iret_depth;

namespace {

int failures = 0;
void expect(bool ok, const std::string& what) {
    if (!ok) { std::printf("FAIL %s\n", what.c_str()); ++failures; }
}

constexpr uint32_t kStop = 0x08000010u;
constexpr uint32_t kMain = 0x08000000u;

// ARM encodings.
constexpr uint32_t ADD_R5 = 0xE2855001u, ADD_R6 = 0xE2866001u, ADD_R7 = 0xE2877001u,
                   ADD_R8 = 0xE2888001u, NOP = 0xE1A00000u;
constexpr uint32_t IRET = 0xE25EF004u;   // subs pc, lr, #4

void put32(std::vector<uint8_t>& v, uint32_t off, uint32_t w) {
    for (int i = 0; i < 4; ++i) v[off + i] = uint8_t(w >> (8 * i));
}

enum class Handler { Plain, LdmCaret, Swi, Nested, Ack };

std::vector<uint8_t> make_bios(Handler h) {
    std::vector<uint8_t> b(16 * 1024, 0);
    put32(b, 0x08, 0xE1B0F00Eu);                 // SWI vector: movs pc, lr
    put32(b, 0x18, 0xEA000038u);                 // IRQ vector: b 0x100
    uint32_t o = 0x100;
    switch (h) {
    case Handler::Plain:
        put32(b, o, IRET); break;
    case Handler::LdmCaret:
        put32(b, o, 0xE24EE004u);                // sub lr, lr, #4
        put32(b, o + 4, 0xE92D4000u);            // stmfd sp!, {lr}
        put32(b, o + 8, 0xE8FD8000u);            // ldmfd sp!, {pc}^
        break;
    case Handler::Swi:
        put32(b, o, 0xEF000000u);                // swi 0
        put32(b, o + 4, IRET); break;
    case Handler::Ack:      // ack lowest pending IF bit, return (no unmask)
    case Handler::Nested: {
        // r0 = IF; ack lowest pending bit; unmask IRQs (nested delivery point);
        // return.
        const uint32_t code[] = {
            0xE3A00301u,   //  0 mov r0, #0x04000000
            0xE3800C02u,   //  1 orr r0, r0, #0x200
            0xE2800002u,   //  2 add r0, r0, #2        (IF)
            0xE1D020B0u,   //  3 ldrh r2, [r0]
            0xE2623000u,   //  4 rsb r3, r2, #0
            0xE0023003u,   //  5 and r3, r2, r3        (lowest set bit)
            0xE1C030B0u,   //  6 strh r3, [r0]         (ack)
            0xE14F4000u,   //  7 mrs r4, spsr          (a nested IRQ clobbers SPSR_irq/LR_irq,
            0xE92D4010u,   //  8 stmfd sp!, {r4, lr}    so save them like a real wrapper does)
            0xE10F1000u,   //  9 mrs r1, cpsr
            0xE3C11080u,   // 10 bic r1, r1, #0x80
            0xE121F001u,   // 11 msr cpsr_c, r1        (unmask: nested delivery point)
            0xE3811080u,   // 12 orr r1, r1, #0x80
            0xE121F001u,   // 13 msr cpsr_c, r1        (mask again)
            0xE8BD4010u,   // 14 ldmfd sp!, {r4, lr}
            0xE16FF004u,   // 15 msr spsr_cxsf, r4
            IRET};         // 16
        const uint32_t ack_only = 7;      // Ack: stop after the strh, then IRET
        const uint32_t n = sizeof(code) / 4;
        for (uint32_t i = 0; i < n; ++i) {
            if (h == Handler::Ack && i >= ack_only) {
                if (i == ack_only) put32(b, o + 4 * i, IRET);
                break;
            }
            put32(b, o + 4 * i, code[i]);
        }
        break; }
    }
    return b;
}

std::vector<uint8_t> make_rom() {
    std::vector<uint8_t> r(0x1000, 0);
    uint32_t w[] = {ADD_R5, ADD_R6, ADD_R7, ADD_R8, NOP, NOP, NOP, NOP};
    for (uint32_t i = 0; i < 8; ++i) put32(r, 4 * i, w[i]);
    return r;
}

struct Fp { unsigned long long cyc; uint32_t pc, cpsr, r[16]; };
struct Result {
    std::vector<Fp> fp;
    uint32_t r[16]; uint32_t cpsr;
    unsigned long long cycles, irqs;
    uint32_t after_irq_pc = 0, after_irq_fp = 0, after_irq_depth = 0;
    bool main_retired_before_return = false;
};

enum class Mode { Direct, Pending, Plain };

// Runs one scenario. `ref` selects the forced-interpreter reference.
Result run(Handler h, Mode mode, uint32_t irq_ret, bool ref, unsigned ie_bits,
           const std::string& tag) {
    const auto biosb = make_bios(h);
    const std::string bpath = "irq_bridge_bios_" + tag + ".bin";
    { std::ofstream f(bpath, std::ios::binary);
      f.write(reinterpret_cast<const char*>(biosb.data()), biosb.size()); }
    gba::GbaBios bios;
    std::string err;
    if (!bios.load_from_file(bpath, "", &err)) { std::printf("bios load: %s\n", err.c_str()); ++failures; return {}; }
    const auto rom = make_rom();

    gba::GbaBus bus; gba::GbaPpu ppu;
    bus.set_bios(&bios);
    bus.set_rom(rom.data(), rom.size());
    bus.io().set_keyinput(0x03FFu);
    bus.io().set_ppu(&ppu);
    bus.io().set_bus(&bus);
    gbarecomp::set_active_bus(&bus);
    gbarecomp::set_active_ppu(&ppu);
    runtime_init(&bus);

    gbarecomp::RuntimeTimingContext t{};
    gbarecomp::runtime_capture_timing_context(t);
    t.cycles = t.pending_cycles = t.event_budget = 0;
    t.vblank_starts = t.yielded_vblank = 0;
    gbarecomp::runtime_restore_timing_context(t);
    gbarecomp::RuntimeArmContext clean;
    clean.returns.clear(); clean.interrupts.clear();
    clean.return_floor = clean.irq_depth = clean.iret_depth = 0;
    clean.resume_pc = clean.irq_from_halt = 0; clean.irq_entries = 0;
    gbarecomp::runtime_restore_arm_context(clean);

    for (int i = 0; i < 16; ++i) g_cpu.R[i] = 0;
    for (unsigned i = 0; i < ARM_BANK_COUNT; ++i) {
        g_cpu.banked_sp[i] = 0; g_cpu.banked_lr[i] = 0; g_cpu.banked_spsr[i] = 0;
    }
    g_cpu.banked_sp[ARM_BANK_IRQ] = 0x03007FA0;
    g_cpu.banked_sp[ARM_BANK_SUPERVISOR] = 0x03007FE0;
    g_cpu.R[13] = 0x03007F00;
    g_cpu.cpsr = 0x1Fu;                    // System mode, ARM, IRQs unmasked
    g_cpu.R[15] = kMain;

    if (ie_bits) {                         // pending IRQ sources
        bus.write16(0x04000200u, uint16_t(ie_bits));   // IE
        bus.write16(0x04000208u, 1);                   // IME
        for (unsigned b = 0; b < 16; ++b)
            if (ie_bits & (1u << b)) bus.io().request_irq(uint16_t(1u << b));
    }
    g_force_interp = ref ? 1 : 0;
    g_runtime_insn_trace = 1u;
    runtime_fp_reset();

    Result res{};
    if (mode == Mode::Direct) {
        g_cpu.R[15] = irq_ret;
        runtime_irq(irq_ret);
        res.after_irq_pc = g_cpu.R[15];
        res.after_irq_fp = runtime_fp_count();
        res.after_irq_depth = g_irq_nest_depth;
        // Did any instruction of the interrupted (mainline) code retire?
        const char* p = "irq_bridge_probe.fp";
        runtime_fp_save_file(p);
        std::ifstream f(p, std::ios::binary);
        uint32_t magic, esz; unsigned long long cnt;
        f.read(reinterpret_cast<char*>(&magic), 4); f.read(reinterpret_cast<char*>(&esz), 4);
        f.read(reinterpret_cast<char*>(&cnt), 8);
        std::vector<RuntimeFpEntry> v(cnt);
        f.read(reinterpret_cast<char*>(v.data()), cnt * sizeof(RuntimeFpEntry));
        for (const auto& e : v) if ((e.pc >> 24) == 0x08u) res.main_retired_before_return = true;
        // The interrupted native frame resumes at its own PC (generated code
        // re-stamps g_cpu.R[15] with it at its next prologue): an over-run by
        // the bridge therefore re-executes already-retired instructions.
        g_cpu.R[15] = irq_ret;
    }
    // Resume the interrupted mainline until the stop address (the "native
    // owner" continuing): production = dispatch R15, reference = forced step.
    for (int i = 0; i < 200 && g_cpu.R[15] != kStop; ++i) {
        if (ref) runtime_force_interp_step();
        else     runtime_dispatch(g_cpu.R[15]);
    }
    g_runtime_insn_trace = 0u;
    const char* p = "irq_bridge_result.fp";
    runtime_fp_save_file(p);
    {
        std::ifstream f(p, std::ios::binary);
        uint32_t magic, esz; unsigned long long cnt;
        f.read(reinterpret_cast<char*>(&magic), 4); f.read(reinterpret_cast<char*>(&esz), 4);
        f.read(reinterpret_cast<char*>(&cnt), 8);
        std::vector<RuntimeFpEntry> v(cnt);
        f.read(reinterpret_cast<char*>(v.data()), cnt * sizeof(RuntimeFpEntry));
        for (const auto& e : v) {
            Fp q{}; q.cyc = e.cycles; q.pc = e.pc; q.cpsr = e.cpsr;
            std::memcpy(q.r, e.r, sizeof(q.r)); res.fp.push_back(q);
        }
    }
    for (int i = 0; i < 16; ++i) res.r[i] = g_cpu.R[i];
    res.cpsr = g_cpu.cpsr; res.cycles = g_runtime_cycles; res.irqs = g_runtime_irq_entries;
    expect(g_irq_nest_depth == 0u, tag + ": IRQ nest depth back to 0");
    gbarecomp::set_active_bus(nullptr);
    std::remove(bpath.c_str());
    return res;
}

bool same(const Result& a, const Result& b) {
    if (a.fp.size() != b.fp.size()) return false;
    for (size_t i = 0; i < a.fp.size(); ++i)
        if (std::memcmp(&a.fp[i], &b.fp[i], sizeof(Fp)) != 0) return false;
    return std::memcmp(a.r, b.r, sizeof(a.r)) == 0 && a.cpsr == b.cpsr &&
           a.cycles == b.cycles && a.irqs == b.irqs;
}

void compare(const char* name, Handler h, Mode m, uint32_t ret, unsigned ie) {
    const Result p = run(h, m, ret, false, ie, std::string(name) + "_prod");
    const Result r = run(h, m, ret, true, ie, std::string(name) + "_ref");
    const bool ok = same(p, r);
    if (std::getenv("IRQB_DUMP")) {
        for (const Result* x : {&p, &r}) {
            std::printf("  %s pcs:", x == &p ? "prod" : "ref ");
            for (const auto& e : x->fp) std::printf(" %x", e.pc);
            std::printf("\n  %s after_irq pc=%08x fp=%u depth=%u\n", x == &p ? "prod" : "ref ",
                        x->after_irq_pc, x->after_irq_fp, x->after_irq_depth);
        }
    }
    std::printf("%s %-34s prod: retired=%zu cycles=%llu irqs=%llu | ref: retired=%zu cycles=%llu irqs=%llu\n",
                ok ? "PASS" : "FAIL", name, p.fp.size(), p.cycles, p.irqs, r.fp.size(), r.cycles, r.irqs);
    if (!ok) {
        ++failures;
        size_t n = std::min(p.fp.size(), r.fp.size());
        for (size_t i = 0; i < n; ++i)
            if (std::memcmp(&p.fp[i], &r.fp[i], sizeof(Fp)) != 0) {
                std::printf("   first diff @%zu prod pc=%08x cyc=%llu cpsr=%08x | ref pc=%08x cyc=%llu cpsr=%08x\n",
                            i, p.fp[i].pc, p.fp[i].cyc, p.fp[i].cpsr, r.fp[i].pc, r.fp[i].cyc, r.fp[i].cpsr);
                for (int k = 0; k < 16; ++k)
                    if (p.fp[i].r[k] != r.fp[i].r[k])
                        std::printf("      r%d prod=%08x ref=%08x\n", k, p.fp[i].r[k], r.fp[i].r[k]);
                break;
            }
    }
    if (m == Mode::Direct) {
        // Exact exception-return boundary (production side).
        expect(p.after_irq_pc == ret, std::string(name) + ": PC at IRQ return == return address");
        expect(!p.main_retired_before_return,
               std::string(name) + ": no interrupted-context instruction retired before return");
        expect(p.after_irq_pc == r.after_irq_pc && p.after_irq_fp == r.after_irq_fp,
               std::string(name) + ": boundary PC/retirement equals reference");
    }
    // Mainline instructions at 0x08000000..0x0800000C each retire exactly once.
    unsigned adds[4] = {0, 0, 0, 0};
    for (const auto& e : p.fp)
        if (e.pc >= kMain && e.pc < kMain + 16 && e.pc >= (m == Mode::Direct ? ret : kMain))
            ++adds[(e.pc - kMain) / 4];
    for (unsigned i = (m == Mode::Direct ? (ret - kMain) / 4 : 0); i < 4; ++i)
        expect(adds[i] == 1, std::string(name) + ": mainline insn " + std::to_string(i) + " retired exactly once");
}

}  // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    // The reported SMA2 shape: non-static IRQ return PC.
    compare("irq_ret_nonstatic_0x04",     Handler::Plain,    Mode::Direct, 0x08000004u, 0);
    compare("irq_ret_static_0x08",        Handler::Plain,    Mode::Direct, 0x08000008u, 0);
    compare("irq_ret_nonstatic_ldm_caret",Handler::LdmCaret, Mode::Direct, 0x08000004u, 0);
    compare("irq_with_swi_in_handler",    Handler::Swi,      Mode::Direct, 0x08000004u, 0);
    compare("irq_in_bridged_mainline",    Handler::Ack,      Mode::Pending, 0, 0x0001u);
    compare("nested_irq_direct",          Handler::Nested,   Mode::Direct, 0x08000004u, 0x0003u);
    compare("nested_irq_in_bridged_main", Handler::Nested,   Mode::Pending, 0, 0x0003u);
    compare("ordinary_miss_no_irq",       Handler::Plain,    Mode::Plain,  0, 0);
    std::printf("%s (%d failure%s)\n", failures ? "FAILED" : "ALL PASSED", failures,
                failures == 1 ? "" : "s");
    return failures ? 1 : 0;
}
