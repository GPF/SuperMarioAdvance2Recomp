// IWRAM code-guard semantics and hook lifecycle (host, no corpus).
//   * effective-change invalidation (byte-identical stores are no-ops), mirrors, unaligned and
//     boundary-straddling stores, adjacent stores;
//   * negative cache (one full compare while the image stays altered);
//   * hook ownership: installed iff invalid; chained to a foreign hook; re-asserted after a stale
//     runtime_restore_arm_context; repeated valid->altered, altered->valid, valid->valid restores.
#include "gba_bus.h"
#include "gba_io.h"
#include "iwram_code_guard.h"
#include "runtime_arm.h"
#include "runtime_context.h"
#include <cstdio>
#include <cstring>
#include <memory>
#include <vector>

using namespace gbarecomp;

static int failures;
static void check(bool yes, const char* name) {
    if (!yes) { ++failures; std::fprintf(stderr, "FAIL %s\n", name); }
}
constexpr uint32_t kBase = 0x03001518u, kLen = 0x360u, kOff = 0x1518u;
static std::vector<uint8_t> g_frozen;
static int g_foreign_calls = 0;
static int foreign_hook(uint32_t, int) { ++g_foreign_calls; return 0; }

// What a generated prologue / dispatch_resolve does: ask the installed hook.
static int exec_at(uint32_t pc) {
    return g_runtime_force_interp_hook ? g_runtime_force_interp_hook(pc, 0) : 0;
}
static void load_image(gba::GbaBus& bus) {
    std::memcpy(bus.iwram_write_ptr("test_load") + kOff, g_frozen.data(), kLen);
}
static bool hook_is_guard_when_invalid(const char* what) {
    const bool ok = iwram_code_guard_valid() || g_runtime_force_interp_hook != nullptr;
    if (!ok) std::fprintf(stderr, "FAIL hook missing while invalid: %s\n", what);
    return ok;
}
static void revalidate(const char* what) {
    check(exec_at(kBase) == 0, what);
    check(iwram_code_guard_valid(), what);
}

int main() {
    g_frozen.resize(kLen);
    for (uint32_t i = 0; i < kLen; ++i) g_frozen[i] = static_cast<uint8_t>(0x40u + i * 7u);
    auto bus = std::make_unique<gba::GbaBus>();
    bus->io().set_bus(bus.get());
    load_image(*bus);
    g_runtime_force_interp_hook = &foreign_hook;                 // a pre-existing hook must be chained, not lost
    iwram_code_guard_install(*bus, kBase, kLen, g_frozen.data());

    // 1. EAGER: the image was already in place at install, so one compare at install validates and drops the hook
    check(iwram_code_guard_valid(), "install with the image in place validates eagerly");
    check(g_runtime_force_interp_hook == &foreign_hook, "no guard hook left installed after eager validation");
    check(iwram_code_guard_stats().full_compares == 1 && iwram_code_guard_stats().revalidations == 1, "exactly one full compare at install");
    check(exec_at(kBase) == 0 && g_foreign_calls > 0, "valid: only the chained foreign hook runs");

    auto inv = [&] { return iwram_code_guard_stats().invalidations; };
    const uint64_t i0 = inv();

    // 2. byte-identical stores of every width are no-ops
    bus->write8(kBase, g_frozen[0]);
    bus->write16(kBase, uint16_t(g_frozen[0] | g_frozen[1] << 8));
    bus->write32(kBase + 4, uint32_t(g_frozen[4]) | uint32_t(g_frozen[5]) << 8 | uint32_t(g_frozen[6]) << 16 | uint32_t(g_frozen[7]) << 24);
    bus->write8(kBase + kLen - 1, g_frozen[kLen - 1]);
    check(inv() == i0 && iwram_code_guard_valid(), "identical stores do not invalidate");

    // 3. stores outside the range, including adjacent bytes, do not invalidate
    bus->write8(kBase - 1, 0xA5);
    bus->write8(kBase + kLen, 0xA5);
    bus->write16(kBase - 2, 0xA5A5);
    bus->write32(kBase + kLen, 0xA5A5A5A5u);
    check(inv() == i0 && iwram_code_guard_valid(), "outside stores do not invalidate");

    // 4. a straddling store whose only in-range byte is unchanged is a no-op; changed in-range byte invalidates
    bus->write32(0x03001515u, (uint32_t(g_frozen[0]) << 24) | 0x00223344u);   // bytes 0x1515..0x1517 outside, 0x1518 unchanged
    check(inv() == i0 && iwram_code_guard_valid(), "straddle with unchanged in-range byte is a no-op");

    struct Case { const char* name; uint32_t addr; int width; uint32_t val; };
    const Case cases[] = {
        {"first byte",              kBase,                 1, uint32_t(g_frozen[0] ^ 1u)},
        {"last byte",               kBase + kLen - 1,      1, uint32_t(g_frozen[kLen - 1] ^ 1u)},
        {"halfword at base",        kBase,                 2, uint32_t(g_frozen[0] ^ 1u) | uint32_t(g_frozen[1]) << 8},
        {"low straddle 16",         kBase - 1,             2, 0x0100u | (uint32_t(g_frozen[0] ^ 2u) << 8)},
        {"low straddle 32",         kBase - 3,             4, (uint32_t(g_frozen[0] ^ 2u) << 24)},
        {"high straddle 16",        kBase + kLen - 1,      2, uint32_t(g_frozen[kLen - 1] ^ 2u)},
        {"high straddle 32",        kBase + kLen - 3,      4, uint32_t(g_frozen[kLen - 3] ^ 2u)},
        {"unaligned 32 inside",     kBase + 0x101,         4, 0xDEADBEEFu},
        {"mirror +0x8000",          kBase + 0x8000u,       1, uint32_t(g_frozen[0] ^ 4u)},
        {"mirror +0x10000",         kBase + 0x10000u,      2, uint32_t(g_frozen[0] ^ 4u) | uint32_t(g_frozen[1]) << 8},
        {"mirror 0x03FF8000 window",0x03FF8000u + kOff,    1, uint32_t(g_frozen[0] ^ 8u)},
    };
    for (const Case& c : cases) {
        const uint64_t before = inv();
        if (c.width == 1) bus->write8(c.addr, uint8_t(c.val));
        else if (c.width == 2) bus->write16(c.addr, uint16_t(c.val));
        else bus->write32(c.addr, c.val);
        check(inv() == before + 1 && !iwram_code_guard_valid(), c.name);
        hook_is_guard_when_invalid(c.name);
        // restore the frozen bytes with identical-width stores (also invalidating) and revalidate
        load_image(*bus);
        revalidate(c.name);
    }

    // 5. negative cache: altered image => exactly one full compare, repeated entries use the cache
    bus->write8(kBase + 8, uint8_t(g_frozen[8] ^ 0x80));
    const uint64_t fc = iwram_code_guard_stats().full_compares;
    check(exec_at(kBase + 8) == 1 && exec_at(kBase + 12) == 1 && exec_at(kBase) == 1, "altered image rejects");
    check(iwram_code_guard_stats().full_compares == fc + 1, "one full compare while altered");
    check(iwram_code_guard_stats().cached_rejects >= 2, "negative cache used");
    check(exec_at(0x03000000u) == 0, "non-range PC unaffected while altered");
    bus->write8(kBase + 8, g_frozen[8]);                         // changing it back is an effective store: invalidates again
    revalidate("changed back and revalidated");

    // 6. bulk DMA path declines when armed, then falls back to observed per-element stores
    check(!bus->dma_copy_ram(0x02000000u, kBase, 64), "dma_copy_ram declines IWRAM destination while armed");
    {
        auto& io = bus->io();
        for (uint32_t i = 0; i < 16; ++i) bus->ewram_ptr()[i] = uint8_t(g_frozen[i] ^ (i == 3 ? 0x10 : 0));
        io.write32(0xD4, 0x02000000u); io.write32(0xD8, kBase);
        io.write16(0xDC, 4); io.write16(0xDE, 0x8400);          // DMA3 immediate, 32-bit, 4 words
        check(!iwram_code_guard_valid(), "DMA into the range invalidates");
        load_image(*bus);
        revalidate("revalidated after DMA");
    }

    // 7. lifecycle: hook ownership across context restores
    RuntimeArmContext stale; runtime_capture_arm_context(stale);          // captured while VALID (hook = foreign)
    check(stale.force_interp == &foreign_hook, "captured foreign hook while valid");
    bus->iwram_code_invalidate("test_bulk_load");                         // bulk writer
    check(g_runtime_force_interp_hook != &foreign_hook && g_runtime_force_interp_hook != nullptr, "invalidate installs the guard hook");
    runtime_restore_arm_context(stale);                                   // stale context clobbers the hook
    // image still equals the frozen one => the restore revalidates eagerly and the foreign hook is back
    check(iwram_code_guard_valid(), "post-restore eager revalidation (image matches)");
    check(g_runtime_force_interp_hook == &foreign_hook, "no guard hook after eager post-restore validation");
    // altered image: stale restore must RE-ASSERT the guard hook and stay invalid
    bus->iwram_write_ptr("test_alter")[kOff + 40] ^= 0x01;
    check(!iwram_code_guard_valid() && g_runtime_force_interp_hook != nullptr, "altered => invalid, hook installed");
    runtime_restore_arm_context(stale);
    check(!iwram_code_guard_valid() && g_runtime_force_interp_hook != nullptr && g_runtime_force_interp_hook != &foreign_hook, "post-restore re-asserts the guard hook on a mismatch");
    check(iwram_code_guard_stats().post_restore_reinstalls >= 1, "post-restore reinstall counted");
    check(exec_at(kBase + 40) == 1, "altered image rejected after stale restore");
    load_image(*bus);
    check(exec_at(kBase) == 0 && iwram_code_guard_valid(), "revalidates once restored");
    check(g_runtime_force_interp_hook == &foreign_hook, "foreign hook back after validation");

    RuntimeArmContext fresh; runtime_capture_arm_context(fresh);
    const uint64_t reinstalls0 = iwram_code_guard_stats().post_restore_reinstalls;
    for (int round = 0; round < 3; ++round) {
        // valid -> altered: production order (device load invalidates BEFORE the context is captured)
        bus->iwram_write_ptr("ckpt_altered")[kOff + 16] ^= 0x55;
        RuntimeArmContext c; runtime_capture_arm_context(c);
        runtime_restore_arm_context(c);
        check(!iwram_code_guard_valid() && g_runtime_force_interp_hook != nullptr && g_runtime_force_interp_hook != &foreign_hook, "valid->altered restore keeps guard");
        check(exec_at(kBase + 16) == 1, "altered image rejected after restore");
        // altered -> valid
        std::memcpy(bus->iwram_write_ptr("ckpt_valid") + kOff, g_frozen.data(), kLen);
        c = RuntimeArmContext{}; runtime_capture_arm_context(c); runtime_restore_arm_context(c);
        check(iwram_code_guard_valid() && g_runtime_force_interp_hook == &foreign_hook, "altered->valid restore revalidates eagerly");
        // valid -> valid (identical bulk reload still invalidates, one compare revalidates)
        std::memcpy(bus->iwram_write_ptr("ckpt_same") + kOff, g_frozen.data(), kLen);
        c = RuntimeArmContext{}; runtime_capture_arm_context(c); runtime_restore_arm_context(c);
        check(iwram_code_guard_valid() && g_runtime_force_interp_hook == &foreign_hook, "valid->valid restore revalidates eagerly, no guard hook");
        check(g_runtime_force_interp_hook == &foreign_hook, "hook state clean after round");
    }
    (void)reinstalls0; (void)fresh;

    // 8. the foreign hook was chained while the guard hook was installed
    check(g_foreign_calls > 0, "foreign hook chained");

    iwram_code_guard_uninstall();
    g_runtime_force_interp_hook = nullptr;
    if (failures) { std::fprintf(stderr, "%d failure(s)\n", failures); return 1; }
    std::puts("iwram_guard_tests passed");
    return 0;
}
