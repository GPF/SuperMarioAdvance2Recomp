# usage: cmake -DBUILD_DIR=<dir> -DTARGET=<target> -DEXPECT=<regex> -DCMAKE_BIN=<cmake> -P expect_compile_error.cmake
execute_process(COMMAND ${CMAKE_BIN} --build ${BUILD_DIR} --target ${TARGET}
                RESULT_VARIABLE rc OUTPUT_VARIABLE out ERROR_VARIABLE err)
if(rc EQUAL 0)
    message(FATAL_ERROR "${TARGET} compiled, but it must be rejected by the compiler")
endif()
if(NOT "${out}${err}" MATCHES "${EXPECT}")
    message(FATAL_ERROR "${TARGET} failed for the wrong reason (expected /${EXPECT}/):\n${out}${err}")
endif()
message(STATUS "${TARGET} rejected as expected (/${EXPECT}/)")
