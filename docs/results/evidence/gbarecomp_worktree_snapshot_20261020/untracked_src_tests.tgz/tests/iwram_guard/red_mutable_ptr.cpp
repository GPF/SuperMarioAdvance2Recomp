// RED: the old mutable accessor must not compile.
#include "gba_bus.h"
void red(gba::GbaBus& bus) { bus.iwram_ptr()[0x1518] = 0; }
