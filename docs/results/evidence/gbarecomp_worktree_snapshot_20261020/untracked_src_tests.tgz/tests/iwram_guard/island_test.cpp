// Native-island mode (relocated IWRAM AOT in the force-interp runner): predicate and dispatch semantics.
#include "gba_bus.h"
#include "iwram_code_guard.h"
#include "runtime_arm.h"
#include <cstdio>
#include <cstring>
#include <memory>

static int failures;
static void check(bool yes, const char* name) { if (!yes) { ++failures; std::fprintf(stderr, "FAIL %s\n", name); } }

static int g_fn_calls = 0;
static void fake_fn_a(void) { ++g_fn_calls; g_cpu.R[15] = 0x08000100u; }   // "function": runs, then exits to ROM
static void fake_fn_b(void) { ++g_fn_calls; g_cpu.R[15] = 0x08000200u; }

// Own dispatch table (this test does not link the empty stub): two ARM IWRAM entries, sorted by address.
struct DispatchEntry { uint32_t addr; uint8_t thumb; uint8_t resume; void (*fn)(void); };
extern "C" const DispatchEntry kDispatchTable[] = {
    {0x03001518u, 0u, 0u, fake_fn_a},
    {0x030015D8u, 0u, 0u, fake_fn_b},
};
extern "C" const unsigned kDispatchTableLen = 2u;

extern "C" int g_force_interp;
static int veto(uint32_t, int) { return 1; }
static int allow(uint32_t, int) { return 0; }

int main() {
    g_runtime_native_island = 0; g_force_interp = 1; g_runtime_force_interp_hook = nullptr;
    // 1. default off: nothing is native
    check(!runtime_island_wants_native(0x03001518u, 0), "island off => interpret");
    g_runtime_native_island = 1;
    // 2. needs the force-interp backend
    g_force_interp = 0;
    check(!runtime_island_wants_native(0x03001518u, 0), "island without force-interp backend => no");
    g_force_interp = 1;
    // 3. only static IWRAM ARM entries
    check(runtime_island_wants_native(0x03001518u, 0), "static ARM IWRAM entry => native");
    check(runtime_island_wants_native(0x030015D8u, 0), "second static entry => native");
    check(runtime_island_wants_native(0x030015D9u, 0) , "low bit ignored");
    check(!runtime_island_wants_native(0x0300151Cu, 0), "non-entry IWRAM pc => interpret");
    check(!runtime_island_wants_native(0x03001518u, 1), "Thumb => interpret");
    check(!runtime_island_wants_native(0x08000000u, 0), "ROM pc => interpret");
    check(!runtime_island_wants_native(0x02000000u, 0), "EWRAM pc => interpret");
    // 4. the guard hook veto (stale / unvalidated image)
    g_runtime_force_interp_hook = &veto;
    check(!runtime_island_wants_native(0x03001518u, 0), "hook veto => interpret");
    g_runtime_force_interp_hook = &allow;
    check(runtime_island_wants_native(0x03001518u, 0), "hook allow => native");
    g_runtime_force_interp_hook = nullptr;
    // 5. dispatch of an entry runs the function; a dispatch that would MISS returns to the runner (no bridge/abort)
    g_cpu.R[15] = 0x03001518u; g_fn_calls = 0;
    runtime_dispatch(g_cpu.R[15]);
    check(g_fn_calls == 1 && g_cpu.R[15] == 0x08000100u, "native entry executed, exit pc handed back");
    g_cpu.R[15] = 0x08000100u;
    runtime_dispatch(g_cpu.R[15]);                       // island miss: must return without bridging
    check(g_cpu.R[15] == 0x08000100u && g_fn_calls == 1, "island miss returns to the runner untouched");
    // 6. hook veto inside dispatch (a native function jumping to a stale function) also returns to the runner
    g_runtime_force_interp_hook = &veto; g_cpu.R[15] = 0x030015D8u;
    runtime_dispatch(g_cpu.R[15]);
    check(g_cpu.R[15] == 0x030015D8u && g_fn_calls == 1, "vetoed dispatch returns, function not run");
    g_runtime_force_interp_hook = nullptr;
    g_runtime_native_island = 0;
    if (failures) { std::fprintf(stderr, "%d failure(s)\n", failures); return 1; }
    std::puts("iwram_island_tests passed");
    return 0;
}
