// GREEN: read-only access and explicitly invalidating writable access compile.
#include "gba_bus.h"
void green_w(gba::GbaBus& bus) { bus.iwram_write_ptr("test")[0x1518] = 0; }
unsigned char green_r(const gba::GbaBus& bus) { return bus.iwram_ptr()[0x1518]; }
unsigned char green_r2(gba::GbaBus& bus) { return bus.iwram_read_ptr()[0x1518]; }
