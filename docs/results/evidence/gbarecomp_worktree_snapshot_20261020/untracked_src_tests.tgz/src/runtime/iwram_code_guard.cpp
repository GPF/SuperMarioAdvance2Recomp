#include "iwram_code_guard.h"
#include <cstring>

namespace gbarecomp {
namespace {
gba::GbaBus* g_bus = nullptr;
uint32_t g_lo = 0, g_len = 0;
const uint8_t* g_frozen = nullptr;
IwramCodeGuardEvent g_ev = nullptr;
bool g_valid = false;
uint64_t g_gen = 0, g_fail_gen = ~0ull;
RuntimeForceInterpHook g_prev = nullptr;
IwramCodeGuardStats g_stats;

int guard_hook(uint32_t pc, int thumb);

void install_hook() {
    if (g_runtime_force_interp_hook == &guard_hook) return;
    g_prev = g_runtime_force_interp_hook;     // chain whatever was there
    g_runtime_force_interp_hook = &guard_hook;
    ++g_stats.hook_installs;
}
void remove_hook() {
    if (g_runtime_force_interp_hook == &guard_hook) g_runtime_force_interp_hook = g_prev;
    g_prev = nullptr;
}
void invalidate(void*, const char* why) {
    ++g_stats.invalidations; ++g_gen;
    if (g_ev) g_ev("INVALIDATE", why, 0);
    g_valid = false;
    install_hook();
}
// One full compare of the live image against the frozen image. Used lazily (first execution inside the range) and
// eagerly (install, after a context restore). Safe at any instant at which no guest instruction is mid-flight: every
// later store goes through the barrier / explicit invalidation, so 'valid' still implies live == frozen.
bool try_revalidate(uint32_t pc) {
    if (g_valid) return true;
    if (g_fail_gen == g_gen) { ++g_stats.cached_rejects; return false; }
    ++g_stats.full_compares;
    if (std::memcmp(g_bus->iwram_read_ptr() + (g_lo & 0x7FFFu), g_frozen, g_len) == 0) {
        g_valid = true; ++g_stats.revalidations;
        if (g_ev) g_ev("REVALIDATE", "", pc);
        return true;
    }
    ++g_stats.rejects; g_fail_gen = g_gen;
    if (g_ev) g_ev("REJECT", "", pc);
    return false;
}
int guard_hook(uint32_t pc, int thumb) {
    ++g_stats.hook_calls;
    const int chained = g_prev ? g_prev(pc, thumb) : 0;
    if (g_valid) { remove_hook(); return chained; }
    if (thumb || pc < g_lo || pc >= g_lo + g_len) return chained;
    if (try_revalidate(pc)) { remove_hook(); return chained; }
    return 1;
}
}  // namespace

void iwram_code_guard_install(gba::GbaBus& bus, uint32_t vma_lo, uint32_t len,
                              const uint8_t* frozen, IwramCodeGuardEvent ev) {
    g_bus = &bus; g_lo = vma_lo; g_len = len; g_frozen = frozen; g_ev = ev;
    g_valid = false; g_gen = 0; g_fail_gen = ~0ull; g_stats = IwramCodeGuardStats{};
    const uint32_t off = vma_lo & 0x7FFFu;
    bus.set_iwram_code_watch(off, off + len, &invalidate, nullptr);
    g_runtime_post_restore_hook = &iwram_code_guard_after_restore;
    invalidate(nullptr, "install");
    // Eager: if the image is already in place (checkpoint restored before install) validate now and drop the hook.
    if (try_revalidate(0)) remove_hook();
}
void iwram_code_guard_uninstall() {
    if (g_bus) g_bus->set_iwram_code_watch(0, 0, nullptr, nullptr);
    remove_hook(); g_bus = nullptr; g_runtime_post_restore_hook = nullptr;
}
void iwram_code_guard_test_assume_valid() { g_valid = true; remove_hook(); }   // RED-CONTROL ONLY
void iwram_code_guard_set_event_sink(IwramCodeGuardEvent ev) { g_ev = ev; }
bool iwram_code_guard_valid() { return g_valid; }
const IwramCodeGuardStats& iwram_code_guard_stats() { return g_stats; }
void iwram_code_guard_after_restore() {
    if (!g_bus || g_valid) return;
    // Eager one-shot revalidation: a restore has just replaced IWRAM wholesale and no guest instruction has run yet.
    // On a match the hook is removed immediately (no per-boundary hook calls until the next invalidation).
    if (try_revalidate(0)) { remove_hook(); return; }
    // restore replaced g_runtime_force_interp_hook with the saved context's value: chain and reinstall
    if (g_runtime_force_interp_hook != &guard_hook) {
        g_prev = g_runtime_force_interp_hook; g_runtime_force_interp_hook = &guard_hook;
        ++g_stats.hook_installs; ++g_stats.post_restore_reinstalls;
        if (g_ev) g_ev("REINSTALL", "post_restore", 0);
    }
}
}  // namespace gbarecomp
