// Scratch PoC: validity guard for relocated (ROM -> IWRAM) AOT code.
// State machine: valid  <=> live IWRAM bytes == frozen image (as last proven by a full compare and
// not invalidated since). An effective bus store / bulk writer calls invalidate(); while invalid the
// force-interp hook is installed and a single full compare revalidates (negative-cached by `gen`).
#pragma once
#include <cstdint>
#include "gba_bus.h"
#include "runtime_arm.h"

namespace gbarecomp {

struct IwramCodeGuardStats {
    uint64_t invalidations = 0, hook_installs = 0, hook_calls = 0, full_compares = 0,
             revalidations = 0, rejects = 0, cached_rejects = 0, post_restore_reinstalls = 0;
};
// Optional event sink (harness/diagnostics): what = "INVALIDATE" | "REVALIDATE" | "REJECT" | "REINSTALL".
using IwramCodeGuardEvent = void (*)(const char* what, const char* detail, uint32_t pc);

// Arm the guard for [vma_lo, vma_lo+len) (GBA address in 0x03000000..) against `frozen`. The guard
// starts INVALID (first execution inside the range does the one full compare). Chains any hook that
// was installed before. `bus` must outlive the guard.
void iwram_code_guard_install(gba::GbaBus& bus, uint32_t vma_lo, uint32_t len,
                              const uint8_t* frozen, IwramCodeGuardEvent ev = nullptr);
void iwram_code_guard_uninstall();
// Diagnostics only: observe state transitions (does not change behaviour).
void iwram_code_guard_set_event_sink(IwramCodeGuardEvent ev);
bool iwram_code_guard_valid();
void iwram_code_guard_test_assume_valid();   // red controls only
const IwramCodeGuardStats& iwram_code_guard_stats();
// Called by runtime_restore_arm_context after it restores g_runtime_force_interp_hook.
void iwram_code_guard_after_restore();

}  // namespace gbarecomp
